﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace CollectionExamples
{
    public class Airplane: IComparable
    {
        public int AirplaneID { get; set; }
        public string Pilot { get; set; }

        public static IComparer SortByPilot
        { get { return (IComparer)new PilotComparer(); } }


        int IComparable.CompareTo(object obj)
        {
            Airplane temp = obj as Airplane;
            if (temp != null)
                return this.AirplaneID.CompareTo(temp.AirplaneID);
            else
                throw new ArgumentException("Parameter is not a Airplane!");
        }
    }
    class PilotComparer: IComparer
    {
        int IComparer.Compare(object o1, object o2)
        {
            Airplane t1 = o1 as Airplane;
            Airplane t2 = o2 as Airplane;
            if (t1 != null && t2 != null)
                return String.Compare(t1.Pilot, t2.Pilot);
            else
                throw new ArgumentException("Parameter is not a Airplane!");
        }
    }
}
