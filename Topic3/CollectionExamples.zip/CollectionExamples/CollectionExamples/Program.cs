﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace CollectionExamples
{
    class Program
    {

        static void Main(string[] args)
        {

            int[] myIntArray;
            myIntArray = new int[5];
            myIntArray[0] = 1;
            Array.Sort(myIntArray);

            ArrayList arrayList = new ArrayList();
            arrayList.Add(5);
            arrayList.Add("sdfsf");
            arrayList.Add(myIntArray);

            Console.WriteLine(arrayList[0]);
            Console.WriteLine(arrayList[1]);
            Console.WriteLine(arrayList[2]);



            Airplane[] Planes = new Airplane[5] {new Airplane() { AirplaneID = 1, Pilot = "John Drew" },
                                                 new Airplane() { AirplaneID = 234, Pilot = "Mary First" },
                                                 new Airplane { AirplaneID = 34, Pilot = "Andy Stown" },
                                                 new Airplane { AirplaneID = 4, Pilot = "Mel Gibbs" },
                                                 new Airplane { AirplaneID = 5, Pilot = "Chucky Nord" } };
            
            
            Console.WriteLine("The unordered set of Airplanes:");
            foreach (Airplane c in Planes)
                Console.WriteLine("{0} {1}", c.AirplaneID, c.Pilot);
            Array.Sort(Planes);
            Console.WriteLine();
            Console.WriteLine("The ordered set of Airplanes:");
            foreach (Airplane c in Planes)
                Console.WriteLine("{0} {1}", c.AirplaneID, c.Pilot);
            Console.WriteLine();
            Array.Sort(Planes, Airplane.SortByPilot);
            Console.WriteLine("Ordering by pilot:");
            foreach (Airplane c in Planes)
                Console.WriteLine("{0} {1}", c.AirplaneID, c.Pilot);
        }
    }
}
