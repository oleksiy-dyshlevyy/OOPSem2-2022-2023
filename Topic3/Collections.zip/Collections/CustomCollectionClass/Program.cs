﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CustomCollectionClass
{

    interface IWrapper<T>
    {
        void SetData(T data);
        T GetData();
    }



    class Wrapper<T> : IWrapper<T>
    {
        private T storedData;
        void IWrapper<T>.SetData(T data)
        {
            this.storedData = data;
        }
        T IWrapper<T>.GetData()
        {
            return this.storedData;
        }
    }

    public static class Helper
    {
        public static IEnumerable<int> GetNumbers()
        {
            int i = 0;
            while (true) yield return i++;
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            foreach (var n in Helper.GetNumbers())
            {
                Console.WriteLine(n);
                if (n == 2) break;
            }

            CustomCollectionClass<int> asd = new CustomCollectionClass<int>();
            foreach (var n in asd)
            {
                Console.WriteLine(n);
            }

            Wrapper<string> stringWrapper = new Wrapper<string>();
            IWrapper<string> storedStringWrapper = stringWrapper;
            storedStringWrapper.SetData("Hello");
            Console.WriteLine("Stored value is {0}", storedStringWrapper.GetData());

            //IWrapper<object> storedObjectWrapper = stringWrapper;//CTE
            IWrapper<object> storedObjectWrapper = (IWrapper<object>)stringWrapper;
           

        }
    }
}
