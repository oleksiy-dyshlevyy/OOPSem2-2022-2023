﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoplingCohesionExample
{
    class HighCohesion
    {
        private int _elementA;
        private int _elementB;

        public int MethodA()
        {
            var returnValue = SomeOtherMethod(_elementA);
            return SomeVeryOtherMethod(_elementB);
        }
        int SomeOtherMethod(int element)
        {
            return element;
        }

        int SomeVeryOtherMethod(int element)
        {
            return element;
        }

        public void PrintValues()
        {
            Console.WriteLine(_elementA);
            Console.WriteLine(_elementB);
        }
    }
}
