﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoplingCohesionExample.TightCoupling
{
    class ClassA
    {
        private bool _elementA;
        public int MethodA()
        {
            if (_elementA)
                return new ClassB()._elementB;

            return 0;
        }

        public void PrintValues()
        {
            new ClassB().MethodB();
        }
    }

    class ClassB
    {
        public int _elementB;

        public void MethodB()
        {
            Console.WriteLine(_elementB);
        }
    }

    // What if we decided we wanted to add extra parameter 
    // in Class2’s constructor and make the default one private?
    // Then we would have to change every usage of Class2 everywhere.
}
