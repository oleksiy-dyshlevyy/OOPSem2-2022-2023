﻿using System;
using System.IO;
using System.Xml.Serialization;

namespace DAL
{
    public class Class1
    {
        public string Read(string connection)
        {
            string data;
            using (FileStream fs = new FileStream(connection, FileMode.OpenOrCreate))
            {
                XmlSerializer formatter = new XmlSerializer(typeof(string));
                try
                {
                    data = (string)formatter.Deserialize(fs);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return data;
        }
    }

}
