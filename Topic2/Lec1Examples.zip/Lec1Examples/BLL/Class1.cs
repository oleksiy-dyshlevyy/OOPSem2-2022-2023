﻿using System;

using DAL;

namespace BLL
{
    public class Class1
    {
        DAL.Class1 dal = new DAL.Class1();

        Class1(string conn)
        {
           string str =  dal.Read(conn);
        }

        public void Select()
        {

        }
    }
}
