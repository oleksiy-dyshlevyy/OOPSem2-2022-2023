﻿using System;

namespace Conlole
{
    public class Class1
    {
    }
}
