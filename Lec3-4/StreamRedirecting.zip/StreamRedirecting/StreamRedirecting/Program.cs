﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace StreamRedirecting
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Some text");
            

            //string path = "C://Text.txt";

            //FileStream fs = new FileStream(path,FileMode.OpenOrCreate,FileAccess.ReadWrite);

            //StreamWriter stream = new StreamWriter(fs);
            
        }
    }
}
