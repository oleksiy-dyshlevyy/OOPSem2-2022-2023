﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace _04RaceCondition
{
    class Program
    {
        private static int i = 0;
        static void Main(string[] args)
        {
            Thread T1 = new Thread(PrintStar);
            T1.Start();

            Thread T2 = new Thread(PrintPlus);
            T2.Start();

            Console.ReadLine();

            // Example 2
            // Creating our two threads. The ThreadStart delegate is points to
            // the method being run in a new thread.
            Thread firstRunner = new Thread(new ThreadStart(firstRun));
            Thread secondRunner = new Thread(new ThreadStart(secondRun));

            // Starting our two threads. Thread.Sleep(10) gives the first Thread
            // 10 miliseconds more time.
            firstRunner.Start();
             Thread.Sleep(10);
            secondRunner.Start();

            Console.ReadKey();
        }

        static void PrintStar()
        {
            for (int counter = 0; counter < 5; counter++)
            {
                Console.Write(" * " + "\t");
            }
        }

        private static void PrintPlus()
        {
            for (int counter = 0; counter < 5; counter++)
            {
                Console.Write(" + " + "\t");
            }
        }

        // Example 2


        public static void firstRun()
        {
            while (i < 10)
            {
                Console.WriteLine("First runner incrementing i from " + i +
                                  " to " + ++i);
                // This avoids that the first runner does all the work before
                // the second one has even started. (Happens on high performance
                // machines sometimes.)
            
                Thread.Sleep(100);
            }
        }

        // This method is being excecuted on the second thread.
        public static void secondRun()
        {
            while (i < 10)
            {
                Console.WriteLine("Second runner incrementing i from " + i +
                                  " to " + ++i);
                
                Thread.Sleep(100);
            }
        }
    }
}
