﻿using System;

namespace LSP_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rect = new Square();
            rect.SetHeight(10);
            rect.SetWidth(2);
            Console.WriteLine(rect.Height != rect.Width);
            Console.WriteLine(rect.CalculateArea());
        }
    }
}
