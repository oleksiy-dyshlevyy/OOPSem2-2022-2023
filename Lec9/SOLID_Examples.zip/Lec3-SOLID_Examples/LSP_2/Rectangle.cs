﻿namespace LSP_2
{
    class Rectangle
    {
        public int Height { get; protected set; }
        public int Width { get; protected set; }

        public virtual void SetHeight(int height)
        {
            this.Height = height;
        }

        public virtual void SetWidth(int width)
        {
            this.Width = width;
        }

        public virtual int CalculateArea()
        {
            return this.Height * this.Width;
        }
    }
}
