﻿namespace LSP_2
{
    class Square : Rectangle
    {
        public override void SetHeight(int height)
        {
            this.Height = height;
            this.Width = height;
        }

        public override void SetWidth(int width)
        {
            this.Width = width;
            this.Height = width;
        }
    }
}
