﻿namespace OCP
{
    interface IShape
    {
        double CalculateTotalArea();
    }
}
