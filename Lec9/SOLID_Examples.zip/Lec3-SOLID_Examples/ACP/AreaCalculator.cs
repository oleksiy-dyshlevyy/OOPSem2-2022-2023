﻿using System;

namespace OCP
{
    internal class AreaCalculator
    {
        public double CalculateTotalArea(IShape[] shapes)
        {
            double area = 0;

            foreach (var shape in shapes)
            {
                area += shape.CalculateTotalArea();
            }
            return area;
        }
    }
}





