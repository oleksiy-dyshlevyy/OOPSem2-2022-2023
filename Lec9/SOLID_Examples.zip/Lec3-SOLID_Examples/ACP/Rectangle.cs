﻿using System;

namespace OCP
{
    class Rectangle : IShape
    {
        public Rectangle(int height, int width)
        {
            this.Height = height;
            this.Width = width;
        }
        public double Height { get; set; }
        public double Width { get; set; }

        public double CalculateTotalArea()
        {
            return this.Height * this.Width;
        }
    }
}
