﻿using System;

namespace OCP
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = new IShape[] { new Rectangle(10, 10), new Circle(2) };
            var areaCalculator = new AreaCalculator();

            var result = areaCalculator.CalculateTotalArea(list);

            Console.WriteLine(result);
        }
    }
}
