﻿using System;

namespace OCP
{
    class Circle : IShape
    {
        public Circle(double radius)
        {
            this.Radius = radius;
        }

        public double Radius { get; set; }

        public double CalculateTotalArea()
        {
            return this.Radius * this.Radius * Math.PI;
        }
    }
}
