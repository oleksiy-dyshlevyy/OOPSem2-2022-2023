﻿namespace SRP
{
    public class User
    {
        public User(string name, string email, int age)
        {
            this.Name = name;
            this.Email = email;
            this.Age = age;
        }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }
    }
}
