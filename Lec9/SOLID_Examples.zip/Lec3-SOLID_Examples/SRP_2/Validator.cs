﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SRP
{
    class Validator : IValidator
    {
        public bool Validate(string email)
        {
            return !email.Contains("dsd@");
        }
    }
}
