﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SRP
{
    interface IValidator
    {
            bool Validate(string email);
    }
}
