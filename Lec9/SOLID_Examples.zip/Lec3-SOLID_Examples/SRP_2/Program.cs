﻿namespace SRP
{
    class Program
    {
        static void Main(string[] args)
        {
            var validator = new DbValidator();

            var userService = new UserRegistrationService(validator);

            var firstUser = userService.Register("user1", "user1@google.com", 18);

            var secondUser = userService.Register("user2", "user2@google.com", 10);
        }
    }
}
