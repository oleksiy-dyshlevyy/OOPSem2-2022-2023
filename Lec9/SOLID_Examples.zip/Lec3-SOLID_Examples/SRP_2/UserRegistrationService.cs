﻿using System;
using System.Net.Mail;

namespace SRP
{
    class UserRegistrationService
    {
        public IValidator validator;

        public UserRegistrationService(IValidator validator)
        {
            this.validator = validator;
        }

        public User Register(string name, string email, int age)
        {
            if (validator.Validate(email))
            {
                throw new Exception("Email is not an email");
            }

            var user = new User(name, email, age);

            SendEmail(new MailMessage("admin@mysite.com", email) { Subject = "Hello " + user.Name });
            LogUser(user);

            return user;
        }

        private void SendEmail(MailMessage message)
        {
            Console.WriteLine("Message sending:" + message.Subject);
            // Some sending logic 
        }

        private void LogUser(User user)
        {
            Console.WriteLine("Registration finished for user:" + user.Name);
            // Some logging logic 
        }
    }
}
