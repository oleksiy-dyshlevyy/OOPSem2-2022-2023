﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIP
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IMessage> messageList = new List<IMessage>();
            messageList.Add(new Email
            { ToAddress = "Address",
                Subject = "Subject",
                Content = "Content"
        });
            messageList.Add(new Sms
            {
               PhoneNumber = "+380444444444",
               Message = "Message"
            });

            Notification notification = new Notification(messageList);
        }
    }
}
