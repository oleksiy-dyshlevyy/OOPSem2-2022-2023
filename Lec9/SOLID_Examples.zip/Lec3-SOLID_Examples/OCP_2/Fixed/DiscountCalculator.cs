﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCP_2.Fixed
{
    class DiscountCalculator: IDiscountCalculator
    {
        private readonly List<IDiscountRule> _discountRules;

        public DiscountCalculator(List<IDiscountRule> discountRules)
        {
            _discountRules = discountRules;
        }

        public decimal Calculate(int itemCount)
        {
            return _discountRules.First(rule => rule.Match(itemCount)).Amount;
        }
    }
}
