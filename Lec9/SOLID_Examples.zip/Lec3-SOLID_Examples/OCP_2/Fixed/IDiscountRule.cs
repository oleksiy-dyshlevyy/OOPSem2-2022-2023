﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCP_2.Fixed
{
    interface IDiscountRule
    {
        decimal Amount { get; }
        bool Match(int itemCount);
    }
}
