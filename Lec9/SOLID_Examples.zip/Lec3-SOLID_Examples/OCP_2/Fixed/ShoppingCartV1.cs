﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCP_2.Fixed
{
    class ShoppingCartV1
    {
        private IList<ICartItem> _items;
        private readonly IDiscountCalculator _discountCalculator;

        public ShoppingCartV1(IDiscountCalculator discountCalculator)
        {
            _discountCalculator = discountCalculator;
        }

        public decimal GetDiscountPercentage()
        {
            return _discountCalculator.Calculate(_items.Count);
        }

        public void Add(ICartItem product)
        {
            //Add an item
        }

        public void Delete(ICartItem product)
        {
            //Delete an item
        }
    }
}
