﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OCP_2.Fixed;

namespace OCP_2
{
    class Program
    {
        static void Main(string[] args)
        {
            var discountRules = new List<IDiscountRule>
            {
               new DiscountRuleTenItems()
            };

            var shoppingCart = new ShoppingCartV1(new DiscountCalculator(discountRules));

            for(int i=0; i<12; i++)
            {
                shoppingCart.Add(new Book());
            }

            Console.WriteLine(shoppingCart.GetDiscountPercentage());
        }
    }
}
