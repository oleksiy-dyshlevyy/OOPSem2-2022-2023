﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCP_2
{
    public interface ICartItem
    {
        Guid Id { get; set; }
        decimal Price { get; set; }
    }
}
