﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCP_2
{
    class ShoppingCart
    {
        private IList<ICartItem> items;

        public decimal GetDiscountPercentage()
        {
            var amount = 0;
            if (items.Count >= 5 && items.Count < 10)
                amount = 10;
            else if (items.Count >= 10 && items.Count < 15)
                amount = 15;
            else if (items.Count >= 15)
                amount = 25;

            return amount;
        }

        public void Add(ICartItem product)
        {
            //Add an item
        }

        public void Delete(ICartItem product)
        {
            //Delete an item
        }
    }
}
