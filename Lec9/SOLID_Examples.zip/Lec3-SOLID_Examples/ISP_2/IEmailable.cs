﻿namespace ISP
{
    public interface IEmailable
    {
        string Name { get; set; }
        string EmailAddress { get; set; }
    }
}
