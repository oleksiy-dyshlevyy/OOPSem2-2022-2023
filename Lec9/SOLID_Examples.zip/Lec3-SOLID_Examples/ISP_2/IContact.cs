﻿namespace ISP
{
    public interface IContact
    {
        string Name { get; set; }
        string EmailAddress { get; set; }
        string Telephone { get; set; }
    }
}
