﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISP
{
    class Program
    {
        static void Main(string[] args)
        {
            var customer = new Customer(){EmailAddress = "test@google.com", Name = "TestName", Telephone = "3333"};

            var dialler = new Dialer();
            var emailer = new Emailer();

            dialler.MakeCall(customer);
            emailer.SendMessage(customer, "subject", "body");
        }
    }
}
