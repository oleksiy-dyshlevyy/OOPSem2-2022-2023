﻿namespace ISP
{
    class Customer : IDialable, IEmailable
    {
        public string Name { get; set; }
        public string EmailAddress { get; set; }
        public string Telephone { get; set; }
    }
}
