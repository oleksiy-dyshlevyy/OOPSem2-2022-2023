﻿namespace ISP
{
    public interface IDialable
    {
        string Telephone { get; set; }
    }
}
