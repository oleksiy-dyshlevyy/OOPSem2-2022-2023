﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISP
{
    public class Dialer
    {
        public void MakeCall(IDialable contact)
        {
            // Code to dial telephone number of contact
            Console.WriteLine("Dialing Telephone - {0}", contact.Telephone);
        }
    }
}
