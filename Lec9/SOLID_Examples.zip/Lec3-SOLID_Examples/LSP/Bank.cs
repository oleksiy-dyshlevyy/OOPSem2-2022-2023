﻿namespace LSP
{
    public class Bank
    {
        public virtual void Withdraw(Account acc, int amount)
        {
            acc.Withdraw(acc.Id, amount);
        }
    }
}
