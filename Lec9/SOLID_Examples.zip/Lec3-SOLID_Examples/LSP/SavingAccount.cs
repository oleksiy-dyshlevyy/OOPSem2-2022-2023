﻿using System;

namespace LSP
{
    public class SavingAccount : Account
    {
        public SavingAccount(int savingAccountId, int balance)
            : base(savingAccountId, balance)
        {

        }

        public override void Withdraw(int accountId, int amount)
        {
            Console.WriteLine("In SavingAccount withdraw");
            this.Balance -= amount - 1;
        }

        public void AddInterest(int interest)
        {
            this.Balance *= interest;
        }
    }
}
