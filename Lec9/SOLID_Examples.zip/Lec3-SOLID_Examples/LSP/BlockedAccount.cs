﻿using System;

namespace LSP
{
    public class BlockedAccount: Account
    {
        public BlockedAccount(int blockedAccountId, int balance)
            : base(blockedAccountId, balance)
        {

        }

        public override void Withdraw(int accountId, int amount)
        {
            throw new Exception("Account is blocked!!!");
        }
    }
}
