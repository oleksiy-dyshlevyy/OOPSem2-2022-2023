﻿using System;

namespace LSP
{
    public class Account
    {
        public Account(int accountId, int balance)
        {
            this.Id = accountId;
            this.Balance = balance;
        }

        public int Balance { get; set; }

        public virtual int Id { get; set; }

        public virtual void Withdraw(int accountId, int amount)
        {
            Console.WriteLine("In base withdraw");
            this.Balance -= amount;
        }
    }
}
