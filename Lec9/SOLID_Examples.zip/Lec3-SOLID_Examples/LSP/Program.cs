﻿using System;

namespace LSP
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank bank = new Bank();

            Account acc = new Account(1, 200);
            bank.Withdraw(acc, 100);
            Console.WriteLine(acc.Balance);

            Account saving = new BlockedAccount(2, 150);
            bank.Withdraw(saving, 100);
            Console.WriteLine(saving.Balance);
        }
    }
}
