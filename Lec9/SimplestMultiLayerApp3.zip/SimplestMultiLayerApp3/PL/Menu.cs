﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BLL;

namespace PL
{
    public class Menu: IMenu
    {
        IExchangeService _exchangeService;
        IDataReadWriteService<int> _readWriteServiceInt;
        IDataReadWriteService<string> _readWriteServiceString;

        public void Start(IExchangeService exchangeService, 
                          IDataReadWriteService<int> readWriteServiceInt,
                          IDataReadWriteService<string> readWriteServiceString)
        {
            _exchangeService = exchangeService;
            PrintCurrentRate();
            decimal sum = ScanSumToConvert();
            PrintConvertedSum(sum);

            _readWriteServiceInt = readWriteServiceInt;
            _readWriteServiceString = readWriteServiceString;
            PrintTypes();
        }

        public void PrintCurrentRate()
        {
            Console.WriteLine($"Current rate in dollar - {_exchangeService.Rate.Dollar:0.00}, euro - {_exchangeService.Rate.Euro:0.00}");
            Console.Write("Input summa in hryvnia: ");
            
        }

        public void PrintConvertedSum(decimal sum)
        {
            Console.WriteLine($"{sum} Hryvnia = {_exchangeService.HryvniaToDollar(sum):0.00} dollar");
            Console.WriteLine($"{sum} Hryvnia = {_exchangeService.HryvniaToEuro(sum):0.00} euro");
        }

        public void PrintTypes()
        {
           
            int number = _readWriteServiceInt.ReadData();
            Console.WriteLine($"number = {number}");

            string str = _readWriteServiceString.ReadData();
            Console.WriteLine($"str = {str}");
        }

        public decimal ScanSumToConvert()
        {
            string s = Console.ReadLine();
            decimal sum = Convert.ToDecimal(s);
            return sum;
        }
    }
}
