﻿using System;

namespace ConfigApp
{
    public class Class1
    {
    }
}
