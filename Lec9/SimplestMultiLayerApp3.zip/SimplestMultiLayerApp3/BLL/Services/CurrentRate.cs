﻿using System;

namespace BLL
{
    public class CurrentRate
    {
        public Decimal Dollar { get; set; }
        public Decimal Euro { get; set; }

    }
}
