﻿using System;
using BLL;
using DAL;
using DataProviderContract;
using XMLProvider;
using PL;

using System.Configuration;


namespace ConsoleApp
{
    class MainApp
    {
        //static IDataContext<ExchangeRate> dataContext;
        //static IDataContext<int> dataContextInt;

        static IExchangeService exchangeService;
        static IDataReadWriteService<int> readWriteServiceInt;
        static IDataReadWriteService<string> readWriteServiceString;

        static IMenu menu;

        static void Main(string[] args)
        {

            string config;
           // ConfigServices();
           //RunServices();
            config = FileConfiguration("ratefile");
            ConfigExchangeService(config);
            InitialCurrentRateSetting();

            config = FileConfiguration("intfile");
            readWriteServiceInt = ConfigReadWriteServices<int>(config);

            config = FileConfiguration("stringfile");
            readWriteServiceString = ConfigReadWriteServices<string>(config);

            InitialReadWriteSetting();

            RunApp();
            
            Console.ReadKey();
        }

        static void RunApp()
        {
            menu = new Menu();
            menu.Start(exchangeService, readWriteServiceInt, readWriteServiceString);
        }

        static string FileConfiguration(string configurationString)
        {
            return ConfigurationManager.AppSettings[configurationString];
        }

        static void ConfigExchangeService(string path)
        {
            IDataContext<ExchangeRate> dataContextER = new DataContext<ExchangeRate>(path);
            dataContextER.DataProvider = new XMLDataProvider<ExchangeRate>();

            exchangeService = new CarrencyExchangeService(dataContextER);

        }

        static void InitialCurrentRateSetting()
        {
            CurrentRate rate = new CurrentRate() { Dollar = 28, Euro = 32 };
            exchangeService.Rate = rate;
        }

        static ReadWriteService<T> ConfigReadWriteServices<T>(string path)
        {
            IDataContext<T> dataContextRW = new DataContext<T>(path);
            dataContextRW.DataProvider = new XMLDataProvider<T>();

            return (new ReadWriteService<T>(dataContextRW));
        }

       
        static void InitialReadWriteSetting()
        {
            readWriteServiceInt.WriteData(12345);
            readWriteServiceString.WriteData("Mama mila ramu");
        }
          
       
    }
}
