﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DRY
{
    class Program
    {
        // DRY improvements
        private static string address = Constants.Address;
        private static string format = Constants.StandardFormat;

        static void Main(string[] args)
        {
            // WET Example
            DoSomething();
            DoSomethingAgain();
            DoSomethingMore();
            DoSomethingExtraordinary();
            Console.ReadLine();

            // DRY Example
            DoSomething1();
            DoSomethingAgain1();
            DoSomethingMore1();
            DoSomethingExtraordinary1();
            Console.ReadLine();
        }

        #region WET Example
        private static void DoSomething()
        {
            string address = "Stockholm, Sweden";
            string format = "{0} is {1}, lives in {2}, age {3}";
            Console.WriteLine(format, "Nils", "a good friend", address, 30);
        }

        private static void DoSomethingAgain()
        {
            string address = "Stockholm, Sweden";
            string format = "{0} is {1}, lives in {2}, age {3}";
            Console.WriteLine(format, "Christian", "a neighbour", address, 54);
        }

        private static void DoSomethingMore()
        {
            string address = "Stockholm, Sweden";
            string format = "{0} is {1}, lives in {2}, age {3}";
            Console.WriteLine(format, "Eva", "my daughter", address, 4);
        }

        private static void DoSomethingExtraordinary()
        {
            string address = "Stockholm, Sweden";
            string format = "{0} is {1}, lives in {2}, age {3}";
            Console.WriteLine(format, "Lilly", "my daughter's best friend", address, 4);
        }
        #endregion

        #region DRY Example
        private static void DoSomething1()
        {
            WriteToConsole("Nils", "a good friend", 30);
        }

        private static void DoSomethingAgain1()
        {
            WriteToConsole("Christian", "a neighbour", 54);
        }

        private static void DoSomethingMore1()
        {
            WriteToConsole("Eva", "my daughter", 4);
        }

        private static void DoSomethingExtraordinary1()
        {
            WriteToConsole("Lilly", "my daughter's best friend", 4);
        }

        private static void WriteToConsole(string name, string description, int age)
        {
            Console.WriteLine(format, name, description, address, age);
        }
        #endregion
    }
}
