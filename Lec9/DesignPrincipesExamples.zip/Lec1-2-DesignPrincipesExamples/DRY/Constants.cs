﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DRY
{
    public class Constants
    {
        public static readonly string Address = "Stockholm, Sweden";
        public static readonly string StandardFormat = "{0} is {1}, lives in {2}, age {3}";
    }
}
