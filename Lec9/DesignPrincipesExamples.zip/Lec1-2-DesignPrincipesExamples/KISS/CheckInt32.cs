﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace KISS
{
    static class CheckInt32
    {
        public static bool IsInt32TryParse(string input)
        {
            int i;
            return Int32.TryParse(input, out i);
        }

        public static bool IsInt32IsDigit(string input)
        {
            foreach (Char c in input)
            {
                if (!Char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        public static bool IsInt32RegEx(string input)
        {
            return Regex.IsMatch(input, @"^\d+$");
        }
    }
}
