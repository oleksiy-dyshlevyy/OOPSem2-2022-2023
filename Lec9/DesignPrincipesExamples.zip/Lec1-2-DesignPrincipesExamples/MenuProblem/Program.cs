﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuProblem
{
    class Program
    {
        static void Main(string[] args)
        {
            string keyPress = "";
            while (keyPress != "x")
            {
                Console.WriteLine("Menu");
                Console.WriteLine("1. Option 1");
                Console.WriteLine("2. Option 2");
                Console.WriteLine("3. Option 3");
                Console.WriteLine("4. Exit - x");

                keyPress = Console.ReadLine();

                switch (keyPress)
                {
                    case "1":
                        
                            Console.WriteLine("1. Option 1");
                            string keyPress1 = "";
                        while (keyPress1 != "x")
                        {
                            Console.WriteLine("SubMenu");
                            Console.WriteLine("1. SubOption 1");
                            Console.WriteLine("2. SubOption 2");
                            Console.WriteLine("3. SubOption 3");
                            Console.WriteLine("4. Exit - x");

                            keyPress1 = Console.ReadLine();
                            switch (keyPress1)
                            {
                                case "1":
                                    Console.WriteLine("1. SubOption 1");
                                    break;
                               case "2":
                                    Console.WriteLine("2. SubOption 2");
                                    break;
                                case "3":
                                    Console.WriteLine("3. SubOption 3");
                                    break;

                                default:

                                    Console.WriteLine("Wrong key - " + keyPress1);
                                    break;
                            }
                        }
                        break;
                    case "2":
                        Console.WriteLine("2. Option 2");
                        string keyPress2 = "";
                        while (keyPress2 != "x")
                        {
                            Console.WriteLine("SubMenu");
                            Console.WriteLine("1. SubOption 1");
                            Console.WriteLine("2. SubOption 2");
                            Console.WriteLine("3. SubOption 3");
                            Console.WriteLine("4. Exit - x");

                            keyPress2 = Console.ReadLine();
                            switch (keyPress2)
                            {
                                case "1":
                                    Console.WriteLine("1. SubOption 1");
                                    break;
                                case "2":
                                    Console.WriteLine("2. SubOption 2");
                                    break;
                                case "3":
                                    Console.WriteLine("3. SubOption 3");
                                    break;

                                default:

                                    Console.WriteLine("Wrong key - " + keyPress2);
                                    break;
                            }
                        }
                        break;
                    case "3":
                        Console.WriteLine("3. Option 3");
                        break;

                    default:
                       
                        Console.WriteLine("Wrong key - " + keyPress);
                        break;
                }
            }
        }

        static void TypicalMenu()
        {

        }
    }
}
