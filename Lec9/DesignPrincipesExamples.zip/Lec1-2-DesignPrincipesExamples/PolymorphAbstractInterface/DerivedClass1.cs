﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphAbstractInterface
{
    class DerivedClass1: BaseClass1
    {
        public override void Hello()
        {
            Console.WriteLine("Derived1");
        }
    }
}
