﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphAbstractInterface
{
    class Program
    {
        static void PolymorphAbstractInterfaceExampleMethod(BaseClass1 bc1)
        {

        }
        static void Main(string[] args)
        {
            BaseClass1 bc1 = new BaseClass1();
            bc1.Hello();
            bc1 = new DerivedClass1();
            bc1.Hello();
            bc1 = new DerivedClass2();
            bc1.Hello();

            DerivedClass1 dc1 = new DerivedClass1();
            PolymorphAbstractInterfaceExampleMethod(bc1);
            PolymorphAbstractInterfaceExampleMethod(dc1);


            Console.ReadKey();
        }
    }
}
