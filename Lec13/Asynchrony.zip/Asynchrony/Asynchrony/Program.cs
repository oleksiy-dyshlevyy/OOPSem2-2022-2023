﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Asynchrony
{
    class Program
    {
        
        static void Main(string[] args)
        {
            // Example 1
            // run only one single method; other method must be commented

            TaskExample.SimpleTaskMethod();
            // TaskExample.ContinuationTask();
            //TaskExample.ParentAndChild();
            // TaskExample.ResultsFromTasks();

             TaskExample.TaskCancellation();

            // Thread.Sleep(5000);

            // Example 2
            //AsyncAwait ta = new AsyncAwait();
            //ta.TaskAsync();

            Thread.Sleep(5000);

            Console.ReadKey();
        }
    }
}
