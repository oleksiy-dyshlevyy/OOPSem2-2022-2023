﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asynchrony
{
    class AsyncAwait
    {
        string text;


        public async Task TaskAsync()
        {
            // Task<T> 
            // Call and await the Task<T>-returning async method in the same statement.
            int result1 = await TaskOfT_MethodAsync();

            // Call and await in separate statements.
            Task<int> integerTask = TaskOfT_MethodAsync();

            // You can do other work that does not rely on integerTask before awaiting.
            text += String.Format("Application can continue working while the Task<T> runs. . . . \r\n");

            int result2 = await integerTask;
            Console.WriteLine(text);

            // Display the values of the result1 variable, the result2 variable, and
            // the integerTask.Result property.
            text += String.Format("\r\nValue of result1 variable:   {0}\r\n", result1);
            text += String.Format("Value of result2 variable:   {0}\r\n", result2);
            text += String.Format("Value of integerTask.Result: {0}\r\n", integerTask.Result);

            // Task
            // Call and await the Task-returning async method in the same statement.
            await Task_MethodAsync();

            // Call and await in separate statements.
            Task simpleTask = Task_MethodAsync();

            // You can do other work that does not rely on simpleTask before awaiting.
            text += String.Format("\r\nApplication can continue working while the Task runs. . . .\r\n");

            await simpleTask;
            Console.WriteLine(text);
        }
        async Task<int> TaskOfT_MethodAsync()
        {
            // The body of the method is expected to contain an awaited asynchronous
            // call.
            // Task.FromResult is a placeholder for actual work that returns a string.
            var today = await Task.FromResult<string>(DateTime.Now.DayOfWeek.ToString());

            // The method then can process the result in some way.
            int leisureHours;
            if (today.First() == 'S')
                leisureHours = 16;
            else
                leisureHours = 5;

            // Because the return statement specifies an operand of type int, the
            // method must have a return type of Task<int>.
            return leisureHours;
        }


        // TASK EXAMPLE
        async Task Task_MethodAsync()
        {
            // The body of an async method is expected to contain an awaited 
            // asynchronous call.
            // Task.Delay is a placeholder for actual work.
            await Task.Delay(2000);
            // Task.Delay delays the following line by two seconds.
            text += String.Format("\r\nSorry for the delay. . . .\r\n");
            Console.WriteLine(text);
            // This method has no return statement, so its return type is Task.  
        }
    }
}
