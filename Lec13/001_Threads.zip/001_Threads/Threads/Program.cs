﻿using System;
using System.Threading;

// Потоки.

namespace Threads
{
    class Program
    {
        // Метод, который планируется выполнять в отдельном потоке.
        static void WriteSecond()
        {
             while (true)
            //for (int i = 0; i < 1000000; i++)
            {
                Console.WriteLine(new string(' ', 10) + "Secondary");
                Thread.Sleep(100);
            }
        }

        static void Main()
        {
            ThreadStart writeSecond = new ThreadStart(WriteSecond);
            Thread thread = new Thread(writeSecond);
            thread.Start();

            while (true)
           //     for(int i = 0; i < 1000000; i++)
            {
                Console.WriteLine("Primary");
                Thread.Sleep(100);
            }
            
            // Delay.
            Console.ReadKey();
        }
    }
}
