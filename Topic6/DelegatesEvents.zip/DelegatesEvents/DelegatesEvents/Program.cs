﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesEvents
{
    class Program
    {
        delegate int myDel();
        static int Methond1()
        {
            return 0;

        }
        static int Methond2()
        {
            return 0;

        }

        static void Main(string[] args)
        {
            myDel del = null ;
            //del = Methond1;
            //del = Methond2;
            //del();

            for (int i = 0; i < 10; i++)
            {
                del += () => {  return i; };
            }

            int a = del();

            #region Example 1

            UserInterface ui = new UserInterface();
            ui.InitiatePowerOn
            ("Vasiliy Pupkin", new OnPowerOnArgs("Power On"));
            Console.ReadKey();

            #endregion

            #region Example 2

            UserInterface2 ui2 = new UserInterface2();
            User u = new User("Vasiliy Pupkin");

            ui2.OnPowerOn += u.HandlePowerOn;


            ui2.InitiatePowerOn();
            
            Console.ReadKey();


            #endregion

        }
    }
}
