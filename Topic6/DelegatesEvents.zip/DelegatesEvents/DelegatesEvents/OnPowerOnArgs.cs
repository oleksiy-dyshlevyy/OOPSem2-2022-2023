﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesEvents
{
    public class OnPowerOnArgs : EventArgs
    {
        public string DisplayText
        {
            get;
            private set;
        }
        public OnPowerOnArgs(string strText)
        {
            DisplayText = strText;
        }
    }
    
}
