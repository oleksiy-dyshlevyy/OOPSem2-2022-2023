﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesEvents
{
    class UserInterface
    {
        public event EventHandler<OnPowerOnArgs> OnPowerOn;
        public UserInterface()
        {
            OnPowerOn += HandlePowerOn;
        }
        public void InitiatePowerOn(object sender, OnPowerOnArgs args)
        {
            OnPowerOn.Invoke(sender, args);
        }
        protected void HandlePowerOn(object sender, OnPowerOnArgs args)
        {
            Console.WriteLine(sender.ToString() + ": " + args.DisplayText);
        }

    }
}
