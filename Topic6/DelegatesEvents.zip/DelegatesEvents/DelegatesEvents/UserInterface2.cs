﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesEvents
{
    public class UserInterface2
    {
        public event EventHandler<OnPowerOnArgs> OnPowerOn;
        public void InitiatePowerOn()
        {
            OnPowerOn.Invoke(this, new OnPowerOnArgs("Power On"));
        }

    }
}
