﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace SerializationExample.JSONSerialization
{
    [DataContract]
    public class PersonJSN
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public int Age { get; set; }
        [DataMember]
        public CompanyJSN Company { get; set; }

        public PersonJSN()
        { }

        public PersonJSN(string name, int age, CompanyJSN comp)
        {
            Name = name;
            Age = age;
            Company = comp;
        }

    }
}
