﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerializationExample.JSONSerialization
{
    public class CompanyJSN
    {
        public string Name { get; set; }

        public CompanyJSN() { }

        public CompanyJSN(string name)
        {
            Name = name;
        }

    }
}
