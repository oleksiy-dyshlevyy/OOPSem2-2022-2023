﻿using SerializationExample.XMLSerialization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using SerializationExample.SOAPSerialization;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Serialization.Json;
using SerializationExample.JSONSerialization;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using SerializationExample.Custom;



namespace SerializationExample
{


    class Program
    {
        static void Main(string[] args)
        {
            #region Binary Serialzaition
            FileStream fs = new FileStream("FullNameSerialize.bin", FileMode.OpenOrCreate, FileAccess.Write);
            FullNameClass fnc = new FullNameClass("Ivan", "Ivanov", "Ivanovich");
            fnc.Print();
            fnc.Serialize(fs);
            fnc = new FullNameClass("Petr", "Petrov", "Petrovich");
            fnc.Print();
            fs = new
            FileStream("FullNameSerialize.bin", FileMode.OpenOrCreate, FileAccess.Read);
            fnc.Deserialize(fs);
            fnc.Print();
            #endregion

            #region SOAP Setrialization
            SOAPSerialization.Person person = new SOAPSerialization.Person("Tom", 29);
            SOAPSerialization.Person person2 = new SOAPSerialization.Person("Bill", 25);
            SOAPSerialization.Person[] people = new SOAPSerialization.Person[] { person, person2 };

            SoapFormatter formatter = new SoapFormatter();

            using (FileStream fs2 = new FileStream("people.soap", FileMode.OpenOrCreate))
            {
                formatter.Serialize(fs2, people);

                Console.WriteLine("Объект сериализован");
            }

            using (FileStream fs2 = new FileStream("people.soap", FileMode.OpenOrCreate))
            {
                SOAPSerialization.Person[] newPeople = (SOAPSerialization.Person[])formatter.Deserialize(fs2);

                Console.WriteLine("Объект десериализован");
                foreach (SOAPSerialization.Person p in newPeople)
                {
                    Console.WriteLine("Имя: {0} --- Возраст: {1}", p.Name, p.Age);
                }
            }
            Console.ReadLine();

            #endregion

            #region XMLSerialization
            XMLSerialization.Person person11 = new XMLSerialization.Person("Tom", 29, new Company("Microsoft"));
            XMLSerialization.Person person22 = new XMLSerialization.Person("Bill", 25, new Company("Apple"));
            XMLSerialization.Person[] people1 = new XMLSerialization.Person[] { person11, person22 };

            XmlSerializer formatter1 = new XmlSerializer(typeof(XMLSerialization.Person[]));

            using (FileStream fs1 = new FileStream("people.xml", FileMode.OpenOrCreate))
            {
                formatter1.Serialize(fs1, people1);
            }

            using (FileStream fs1 = new FileStream("people.xml", FileMode.OpenOrCreate))
            {
                XMLSerialization.Person[] newpeople = (XMLSerialization.Person[])formatter1.Deserialize(fs1);

                foreach (XMLSerialization.Person p in newpeople)
                {
                    Console.WriteLine("Имя: {0} --- Возраст: {1} --- Компания: {2}", p.Name, p.Age, p.Company.Name);
                }
            }
            Console.ReadLine();

            #endregion

            #region JSON Serialization

            PersonJSN personjsn1 = new PersonJSN("Tom", 29, new CompanyJSN("Microsoft"));
            PersonJSN personjsn2 = new PersonJSN("Bill", 25, new CompanyJSN("Apple"));
            PersonJSN[] peoplejsn = new PersonJSN[] { personjsn1, personjsn2 };

            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(PersonJSN[]));

            using (FileStream fsjsn = new FileStream("people.json", FileMode.OpenOrCreate))
            {
                jsonFormatter.WriteObject(fsjsn, people);
            }

            using (FileStream fsjsn = new FileStream("people.json", FileMode.OpenOrCreate))
            {
                PersonJSN[] newpeople = (PersonJSN[])jsonFormatter.ReadObject(fs);

                foreach (PersonJSN p in newpeople)
                {
                    Console.WriteLine("Имя: {0} --- Возраст: {1} --- Компания: {2}", p.Name, p.Age, p.Company.Name);
                }
            }
            Console.ReadLine();

            #endregion

            #region Custom Serialization
            // This is the name of the file holding the data. You can use any file extension you like.
            string fileName = "dataStuff.myData";

            // Use a BinaryFormatter or SoapFormatter.
            IFormatter formatterB = new BinaryFormatter();
            //IFormatter formatter = new SoapFormatter();

            SerializeItem(fileName, formatter); // Serialize an instance of the class.
            DeserializeItem(fileName, formatter); // Deserialize the instance.
            Console.WriteLine("Done");
            Console.ReadLine();

            #endregion
        }
        public static void SerializeItem(string fileName, IFormatter formatter)
        {
            // Create an instance of the type and serialize it.
            MyItemType t = new MyItemType();
            t.MyProperty = "Hello World";

            FileStream s = new FileStream(fileName, FileMode.Create);
            formatter.Serialize(s, t);
            s.Close();
        }


        public static void DeserializeItem(string fileName, IFormatter formatter)
        {
            FileStream s = new FileStream(fileName, FileMode.Open);
            MyItemType t = (MyItemType)formatter.Deserialize(s);
            Console.WriteLine(t.MyProperty);
        }

    }



}
